var userModel= require('../models/user-models');

module.exports={
 
    fetchData:function(req, res){
  
      userModel.fetchData(function(data){
          res.render('home',{userData:data});
      })
    },
    uploadData:function(req,res){
        var {file_name,selected_option} = req.body;
        userModel.uploadData(file_name,function(data){
            res.render("display",{msg:"Data uploded into database"});
            console.log("Records uploded");
        });
    }
}

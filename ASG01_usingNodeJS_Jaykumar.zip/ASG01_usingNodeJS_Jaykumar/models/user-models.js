var mongoose=require('mongoose');
var db = require('../config/database');

//var csv = require("fast-csv");

var fs = require('fs');

//var csvfile = __dirname + "/../public/files/products.csv";

//var stream = fs.createReadStream(csvfile);

//var fs = require('fs')

// create an schema
var userSchema = new mongoose.Schema({
            name: String,
            img:String,
            summary:String
        });

userTable=mongoose.model('table_movies',userSchema);
        
module.exports={
     
     fetchData:function(callback){
        var userData=userTable.find({});
        userData.exec(function(err, data){
            if(err) throw err;
            return callback(data);
        })
        
     },
     uploadData:function(file_name,callback){
         console.log(file_name);

         jsonData = JSON.parse(fs.readFileSync(file_name, 'utf-8'));
         console.log(jsonData);
         var i = 0;
         while (i < jsonData.length){
             userData = new userTable(jsonData[i]);
             console.log("New :"+userData);
               if(i+1 == jsonData.length){
                  userData.save(function(err,data){
                     if(err) throw err;
                     return callback(data);
                  });
               }
               else{
                  userData.save();
               }
               i++;
         }
        /* userData = new userTable(jsonData[i+1]);
         console.log("New :"+userData);
         userData.save(function(err,data){
            if(err) throw err;
            return callback(data);
         });*/
         
     }
}//end of fetchData Models
